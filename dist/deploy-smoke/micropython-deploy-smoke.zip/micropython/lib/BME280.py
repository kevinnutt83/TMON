from machine import Pin, I2C
import time
import settings
from time import sleep

I2C_ADDR = settings.i2cAddr_BME280

t_fine = 0.0

class BME280: 
    def __init__(self, i2c=None, address=I2C_ADDR):
        """
        Supports TWO separate BME280 sensors on different pins.
        - i2c=None  → legacy / interior enclosure (DEVICE_TEMP pins)
        - i2c=object → any custom I2C bus (used for exterior probe)
        """
        if i2c is None:
            # Interior enclosure sensor (original pin set)
            self.i2c = I2C(0, scl=Pin(settings.DEVICE_TEMP_SCL_PIN),
                           sda=Pin(settings.DEVICE_TEMP_SDA_PIN), freq=400000)
        else:
            self.i2c = i2c
            
        self.address = address
        
        self.calib = []
        # Per-instance calibration data (not module globals)
        self.digT = []
        self.digP = []
        self.digH = []
        self.t_fine = 0.0

        self.osrs_t = 1 #Temperature oversampling x 1
        self.osrs_p = 1 #Pressure oversampling x 1
        self.osrs_h = 1 #Humidity oversampling x 1
        self.mode   = 3 #Normal mode
        self.t_sb   = 5 #Tstandby 1000ms
        self.filter = 0 #filter off
        self.spi3w_en = 0   #3-wire SPI Disable

        ctrl_meas_reg = (self.osrs_t << 5) | (self.osrs_p << 2) | self.mode
        config_reg    = (self.t_sb << 5) | (self.filter << 2) | self.spi3w_en
        ctrl_hum_reg  = self.osrs_h

        self.writeReg(0xF2, ctrl_hum_reg)
        self.writeReg(0xF4, ctrl_meas_reg)
        self.writeReg(0xF5, config_reg)
            
    def writeReg(self, cmd, val):
        self.i2c.writeto_mem(int(self.address), int(cmd), bytes([int(val)]))
        
    def get_calib_param(self):
        self.calib = []
        self.digT = []
        self.digP = []
        self.digH = []
        for i in range (0x88,0x88+24):
            rdate = self.i2c.readfrom_mem(int(self.address), int(i), 1)
            self.calib.append(rdate[0])
        rdate2 = self.i2c.readfrom_mem(int(self.address), int(0xA1), 1)
        self.calib.append(rdate2[0])
        for i in range (0xE1,0xE1+7):
            rdate3 = self.i2c.readfrom_mem(int(self.address), int(i), 1)
            self.calib.append(rdate3[0])

        self.digT.append((self.calib[1] << 8) | self.calib[0])
        self.digT.append((self.calib[3] << 8) | self.calib[2])
        self.digT.append((self.calib[5] << 8) | self.calib[4])
        self.digP.append((self.calib[7] << 8) | self.calib[6])
        self.digP.append((self.calib[9] << 8) | self.calib[8])
        self.digP.append((self.calib[11]<< 8) | self.calib[10])
        self.digP.append((self.calib[13]<< 8) | self.calib[12])
        self.digP.append((self.calib[15]<< 8) | self.calib[14])
        self.digP.append((self.calib[17]<< 8) | self.calib[16])
        self.digP.append((self.calib[19]<< 8) | self.calib[18])
        self.digP.append((self.calib[21]<< 8) | self.calib[20])
        self.digP.append((self.calib[23]<< 8) | self.calib[22])
        self.digH.append( self.calib[24] )
        self.digH.append((self.calib[26]<< 8) | self.calib[25])
        self.digH.append( self.calib[27] )
        self.digH.append((self.calib[28]<< 4) | (0x0F & self.calib[29]))
        self.digH.append((self.calib[30]<< 4) | ((self.calib[29] >> 4) & 0x0F))
        self.digH.append( self.calib[31] )
        
        for i in range(1,2):
            if self.digT[i] & 0x8000:
                self.digT[i] = (-self.digT[i] ^ 0xFFFF) + 1

        for i in range(1,8):
            if self.digP[i] & 0x8000:
                self.digP[i] = (-self.digP[i] ^ 0xFFFF) + 1

        for i in range(0,6):
            if self.digH[i] & 0x8000:
                self.digH[i] = (-self.digH[i] ^ 0xFFFF) + 1  

    def readData(self):
        data = []
        for i in range (0xF7, 0xF7+8):
            rdate = self.i2c.readfrom_mem(int(self.address), int(i), 1)
            data.append(rdate[0])
        pres_raw = (data[0] << 12) | (data[1] << 4) | (data[2] >> 4)
        temp_raw = (data[3] << 12) | (data[4] << 4) | (data[5] >> 4)
        hum_raw  = (data[6] << 8)  |  data[7]
        
        pressure = self.compensate_P(pres_raw)
        temperature = self.compensate_T(temp_raw)
        var_h = self.compensate_H(hum_raw)
        return [pressure, temperature, var_h]

    def compensate_P(self, adc_P):
        pressure = 0.0
        
        v1 = (self.t_fine / 2.0) - 64000.0
        v2 = (((v1 / 4.0) * (v1 / 4.0)) / 2048) * self.digP[5]
        v2 = v2 + ((v1 * self.digP[4]) * 2.0)
        v2 = (v2 / 4.0) + (self.digP[3] * 65536.0)
        v1 = (((self.digP[2] * (((v1 / 4.0) * (v1 / 4.0)) / 8192)) / 8)  + ((self.digP[1] * v1) / 2.0)) / 262144
        v1 = ((32768 + v1) * self.digP[0]) / 32768
        
        if v1 == 0:
            return 0
        pressure = ((1048576 - adc_P) - (v2 / 4096)) * 3125
        if pressure < 0x80000000:
            pressure = (pressure * 2.0) / v1
        else:
            pressure = (pressure / v1) * 2
        v1 = (self.digP[8] * (((pressure / 8.0) * (pressure / 8.0)) / 8192.0)) / 4096
        v2 = ((pressure / 4.0) * self.digP[7]) / 8192.0
        pressure = pressure + ((v1 + v2 + self.digP[6]) / 16.0)  
        return (pressure/100)

    def compensate_T(self, adc_T):
        v1 = (adc_T / 16384.0 - self.digT[0] / 1024.0) * self.digT[1]
        v2 = (adc_T / 131072.0 - self.digT[0] / 8192.0) * (adc_T / 131072.0 - self.digT[0] / 8192.0) * self.digT[2]
        self.t_fine = v1 + v2
        temperature = self.t_fine / 5120.0
        return temperature

    def compensate_H(self, adc_H):
        var_h = self.t_fine - 76800.0
        if var_h != 0:
            var_h = (adc_H - (self.digH[3] * 64.0 + self.digH[4]/16384.0 * var_h)) * (self.digH[1] / 65536.0 * (1.0 + self.digH[5] / 67108864.0 * var_h * (1.0 + self.digH[2] / 67108864.0 * var_h)))
        else:
            return 0
        var_h = var_h * (1.0 - self.digH[0] * var_h / 524288.0)
        if var_h > 100.0:
            var_h = 100.0
        elif var_h < 0.0:
            var_h = 0.0
        return var_h


if __name__ == '__main__':
    sensor = BME280()
    sensor.get_calib_param()
    sleep(1)
    try:
        data = sensor.readData()
        print("pressure : %7.2f hPa" %data[0])
        print("temp : %-6.2f ℃" %data[1])
        print("hum : %6.2f ％" %data[2])
    except KeyboardInterrupt:
        pass
# TMON Version 2.00.1g - Main entry point (CLEANED & OPTIMIZED)
# - connectLora() now runs directly as a permanent background task
# - Removed redundant lora_comm_task wrapper (new lora.py handles its own retries)
# - Cleaner structure, same behavior, full original logic preserved

import uasyncio as asyncio
import settings
import sdata
import utime as time
from sampling import sampleEnviroment
from utils import (
    checkLogDirectory, debug_print, load_persisted_unit_name,
    load_persisted_unit_id, persist_unit_id, get_machine_id,
    periodic_provision_check, load_persisted_wordpress_api_url,
    load_persisted_node_type, load_persisted_custom_settings, log_exception
)
from lora import connectLora, log_error, TMON_AI, check_missed_syncs, periodic_wp_sync
from ota import check_for_update, apply_pending_update
from oled import update_display, display_message
from settings_apply import load_applied_settings_on_boot, settings_apply_loop
try:
    from user_commands import user_commands_task
except Exception:
    user_commands_task = None
try:
    from engine_controller import engine_loop
except Exception:
    engine_loop = None
try:
    import urequests as requests
except Exception:
    requests = None
from wifi import connectToWifiNetwork, wifi_rssi_monitor
import uos as os
import gc
import machine
try:
    import random
except Exception:
    random = None

checkLogDirectory()


def _record_startup_exception(context, exc):
    msg = f"{context}: {type(exc).__name__}: {exc}"
    try:
        sdata.error_count = int(getattr(sdata, 'error_count', 0) or 0) + 1
        sdata.last_error = msg
    except Exception:
        pass
    try:
        print(f"[MAIN][WARN] {msg}")
    except Exception:
        pass

# Apply any previously applied settings snapshot on boot
try:
    load_applied_settings_on_boot()
except Exception as e:
    _record_startup_exception('load_applied_settings_on_boot', e)

script_start_time = time.ticks_ms()

# Detect and persist MACHINE_ID on first boot if missing
try:
    if settings.MACHINE_ID is None:
        mid = get_machine_id()
        if mid:
            settings.MACHINE_ID = mid
            try:
                with open(settings.MACHINE_ID_FILE, 'w') as f:
                    f.write(mid)
            except Exception as e:
                _record_startup_exception('persist_machine_id', e)
except Exception as e:
    _record_startup_exception('machine_id_bootstrap', e)

# Load persisted UNIT_ID mapping if available
try:
    stored_uid = load_persisted_unit_id()
    if stored_uid and str(stored_uid) != str(settings.UNIT_ID):
        settings.UNIT_ID = str(stored_uid)
    try:
        from utils import provisioning_log
        provisioning_log(f"[BOOT] Loaded persisted UNIT_ID: {settings.UNIT_ID}")
    except Exception:
        print(f"[BOOT] Loaded persisted UNIT_ID: {settings.UNIT_ID}")
except Exception as e:
    _record_startup_exception('load_persisted_unit_id', e)

# Load persisted UNIT_Name mapping if available
try:
    stored_uname = load_persisted_unit_name()
    if stored_uname and str(stored_uname) != str(settings.UNIT_Name):
        settings.UNIT_Name = str(stored_uname)
    try:
        from utils import provisioning_log
        provisioning_log(f"[BOOT] Loaded persisted UNIT_Name: {settings.UNIT_Name}")
    except Exception:
        print(f"[BOOT] Loaded persisted UNIT_Name: {settings.UNIT_Name}")
except Exception as e:
    _record_startup_exception('load_persisted_unit_name', e)

# Load persisted WORDPRESS_API_URL before starting tasks
try:
    load_persisted_wordpress_api_url()
except Exception as e:
    _record_startup_exception('load_persisted_wordpress_api_url', e)

# Load persisted NODE_TYPE if available before starting tasks
try:
    _nt = load_persisted_node_type()
    if _nt:
        settings.NODE_TYPE = _nt
except Exception as e:
    _record_startup_exception('load_persisted_node_type', e)

# Load persisted custom settings that are not part of the staged-settings allowlist.
try:
    load_persisted_custom_settings()
except Exception as e:
    _record_startup_exception('load_persisted_custom_settings', e)

def get_script_runtime():
    now = time.ticks_ms()
    return (now - script_start_time) // 1000

# Simple provisioned check
_provision_warned = False
def is_provisioned():
    global _provision_warned
    try:
        flag = getattr(settings, 'PROVISIONED_FLAG_FILE', '/logs/provisioned.flag')
        wp_url = str(getattr(settings, 'WORDPRESS_API_URL', '')).strip()
        if wp_url:
            return True
        os.stat(flag)
        return True
    except Exception:
        if not _provision_warned:
            try:
                from utils import provisioning_log
                provisioning_log('[WARN] Device not marked provisioned (no flag or WORDPRESS_API_URL).')
            except Exception:
                print('[WARN] Device not marked provisioned (no flag or WORDPRESS_API_URL).')
            _provision_warned = True
        return False

class TaskManager:
    def __init__(self):
        self.tasks = []
        self._task_names = set()
    def add_task(self, coro_func, name, interval):
        task_name = str(name)
        if task_name in self._task_names:
            return False
        self._task_names.add(task_name)
        self.tasks.append({
            'coro_func': coro_func,
            'name': task_name,
            'interval': interval,
            'last_run': 0,
            'task': None
        })
        return True
    async def run(self):
        for t in self.tasks:
            t['task'] = asyncio.create_task(self._task_wrapper(t))
        await asyncio.gather(*(t['task'] for t in self.tasks if t['task'] is not None))
    async def _task_wrapper(self, t):
        while True:
            start = time.ticks_ms()
            try:
                await t['coro_func']()
            except Exception as e:
                await log_exception(f"Task {t['name']}", e)
            t['last_run'] = time.ticks_ms()
            elapsed = (t['last_run'] - start) // 1000
            sleep_time = max(0, t['interval'] - elapsed)
            await asyncio.sleep(sleep_time)

# First-boot provisioning check-in
async def first_boot_provision():
    try:
        flag = settings.PROVISIONED_FLAG_FILE
    except Exception:
        flag = '/logs/provisioned.flag'
    already = False
    try:
        if os.stat(flag):
            already = True
    except Exception:
        already = False
    if already:
        return
    hub = getattr(settings, 'TMON_ADMIN_API_URL', '')
    if not hub or not requests:
        return
    try:
        await connectToWifiNetwork()
        mid = get_machine_id()
        body = {
            'unit_id': settings.UNIT_ID,
            'machine_id': mid,
            'firmware_version': getattr(settings, 'FIRMWARE_VERSION', ''),
            'node_type': getattr(settings, 'NODE_TYPE', ''),
        }
        url = hub.rstrip('/') + '/wp-json/tmon-admin/v1/device/check-in'
        try:
            resp = requests.post(url, json=body, timeout=10)
        except TypeError:
            resp = requests.post(url, json=body)
        ok = (resp is not None and getattr(resp, 'status_code', 0) == 200)
        if ok:
            try:
                with open(flag, 'w') as f:
                    f.write('ok')
            except Exception as e:
                await log_exception('first_boot_provision.write_flag', e)
            try:
                settings.UNIT_PROVISIONED = True
            except Exception as e:
                await log_exception('first_boot_provision.set_provisioned', e)
            try:
                resp_json = resp.json()
            except Exception:
                resp_json = {}
            try:
                unit_name = (resp_json.get('unit_name') or '').strip()
                if unit_name:
                    from utils import persist_unit_name
                    persist_unit_name(unit_name)
                    settings.UNIT_Name = unit_name
                    await debug_print('first_boot_provision: UNIT_Name persisted', 'PROVISION')
            except Exception as e:
                await log_exception('first_boot_provision.persist_unit_name', e)
            try:
                new_uid = resp_json.get('unit_id')
                if new_uid and str(new_uid).strip():
                    if str(new_uid).strip() != str(settings.UNIT_ID):
                        settings.UNIT_ID = str(new_uid).strip()
                        persist_unit_id(settings.UNIT_ID)
                        await debug_print('first_boot_provision: UNIT_ID persisted', 'PROVISION')
            except Exception as e:
                await log_exception('first_boot_provision.persist_unit_id', e)
            try:
                await display_message("Provisioned", 2)
            except Exception as e:
                await log_exception('first_boot_provision.display_provisioned', e)
            try:
                site_val = (resp_json.get('site_url') or resp_json.get('wordpress_api_url') or '').strip()
                role_val = (resp_json.get('role') or '').strip()
                if site_val:
                    from utils import persist_wordpress_api_url
                    persist_wordpress_api_url(site_val)
                if role_val:
                    settings.NODE_TYPE = role_val
            except Exception as e:
                await log_exception('first_boot_provision.persist_site_or_role', e)
            try:
                machine.soft_reset()
            except Exception as e:
                await log_exception('first_boot_provision.soft_reset', e)
        else:
            try:
                await display_message("Provision Failed", 2)
            except Exception as e:
                await log_exception('first_boot_provision.display_failed', e)
    except Exception as e:
        await log_exception('first_boot_provision', e)

# Sample task
async def sample_task():
    if not is_provisioned():
        await asyncio.sleep(1)
        return
    loop_start_time = time.ticks_ms()
    from utils import led_status_flash
    led_status_flash('INFO')
    if getattr(settings, 'DEVICE_SUSPENDED', False):
        await debug_print("suspended: skip sample", "WARN")
    else:
        await sampleEnviroment()
    sdata.loop_runtime = (time.ticks_ms() - loop_start_time) // 1000
    sdata.script_runtime = get_script_runtime()
    sdata.free_mem = gc.mem_free()
    try:
        led_status_flash('SUCCESS')
        sdata.cpu_temp = machine.ADC(4).read_u16() * 3.3 / 65535
    except Exception:
        led_status_flash('ERROR')
        sdata.cpu_temp = 0
    from utils import update_sys_voltage, record_field_data
    sdata.sys_voltage = update_sys_voltage()
    sdata.error_count = getattr(TMON_AI, 'error_count', 0)
    sdata.last_error = getattr(TMON_AI, 'last_error', '')
    record_field_data()
    await debug_print(f"sample: lr={sdata.loop_runtime}s sr={sdata.script_runtime}s mem={sdata.free_mem}", "INFO")
    try:
        from utils import maybe_gc
        maybe_gc("sample_task", min_interval_ms=5000, mem_free_below=35 * 1024)
    except Exception:
        pass
    led_status_flash('INFO')

# Periodic field data task
async def periodic_field_data_task():
    from utils import send_field_data_log, send_field_data_via_lora
    while True:
        if not is_provisioned():
            await asyncio.sleep(2)
            continue
        try:
            if getattr(settings, 'DEVICE_SUSPENDED', False):
                await debug_print("suspended: skip sfd send", "WARN")
            else:
                if str(getattr(settings, 'NODE_TYPE', 'base')).lower() == 'remote':
                    await send_field_data_via_lora()
                else:
                    await send_field_data_log()
        except Exception as e:
            await log_exception('periodic_field_data_task', e)
        try:
            from utils import maybe_gc
            maybe_gc("field_data_send", min_interval_ms=12000, mem_free_below=40 * 1024)
        except Exception:
            pass
        await asyncio.sleep(settings.FIELD_DATA_SEND_INTERVAL)

# Periodic command poll task
async def periodic_command_poll_task():
    try:
        from wprest import poll_device_commands
    except Exception:
        poll_device_commands = None
    interval = int(getattr(settings, 'COMMANDS_POLL_INTERVAL_S', 20))
    jitter = float(getattr(settings, 'COMMANDS_POLL_JITTER_S', 0))
    while True:
        if not is_provisioned():
            await asyncio.sleep(2)
            continue
        if poll_device_commands and not getattr(settings, 'DEVICE_SUSPENDED', False):
            try:
                await poll_device_commands()
            except Exception as e:
                await log_exception('periodic_command_poll_task', e)
            try:
                from utils import maybe_gc
                maybe_gc("cmd_poll", min_interval_ms=12000, mem_free_below=40 * 1024)
            except Exception:
                pass
        sleep_s = max(2, interval)
        if jitter > 0 and random:
            sleep_s += random.uniform(0, jitter)
        await asyncio.sleep(sleep_s)


async def periodic_diagnostics_task():
    try:
        from wprest import send_diagnostics_to_wp
    except Exception:
        send_diagnostics_to_wp = None
    interval = int(getattr(settings, 'DIAGNOSTIC_SEND_INTERVAL_S', 300))
    while True:
        if not is_provisioned():
            await asyncio.sleep(2)
            continue
        if send_diagnostics_to_wp and not getattr(settings, 'DEVICE_SUSPENDED', False):
            try:
                await send_diagnostics_to_wp()
            except Exception as e:
                await log_exception('periodic_diagnostics_task', e)
        await asyncio.sleep(interval)

# ========================== TASK SETUP ==========================
tm = TaskManager()
tm.add_task(first_boot_provision, 'first_boot_provision', 0)
if settings.SAMPLE_TEMP or getattr(settings, 'SAMPLE_HUMID', False) or getattr(settings, 'SAMPLE_BAR', False):
    tm.add_task(sample_task, 'sample', 30)
tm.add_task(periodic_field_data_task, 'field_data', settings.FIELD_DATA_SEND_INTERVAL)
tm.add_task(periodic_command_poll_task, 'command_poll', 10)
tm.add_task(check_for_update, 'ota_check', 3600)
tm.add_task(apply_pending_update, 'ota_apply', settings.OTA_APPLY_INTERVAL_S)
if settings.ENABLE_OLED:
    tm.add_task(update_display, 'display', settings.OLED_UPDATE_INTERVAL_S)
tm.add_task(settings_apply_loop, 'settings_apply', 60)
if engine_loop:
    tm.add_task(engine_loop, 'engine', settings.ENGINE_POLL_INTERVAL_S)
tm.add_task(wifi_rssi_monitor, 'wifi_rssi', settings.WIFI_SIGNAL_SAMPLE_INTERVAL_S)
tm.add_task(periodic_provision_check, 'provision_check', settings.PROVISION_CHECK_INTERVAL_S)
tm.add_task(check_missed_syncs, 'missed_syncs', 60)
tm.add_task(periodic_diagnostics_task, 'diagnostics', int(getattr(settings, 'DIAGNOSTIC_SEND_INTERVAL_S', 300)))
# If running as base and WP sync helpers are available, schedule the periodic WP sync
try:
    if str(getattr(settings, 'NODE_TYPE', '')).lower() == 'base':
        tm.add_task(periodic_wp_sync, 'wp_sync', 300)
except Exception as e:
    _record_startup_exception('add_wp_sync_task', e)
if user_commands_task:
    tm.add_task(user_commands_task, 'user_commands', 0)

# ========================== MAIN ENTRY POINT ==========================
async def main():
    # Launch permanent LoRa task directly (new bulletproof version)
    asyncio.create_task(connectLora())
    # Run all other periodic tasks
    await tm.run()

# Start remote deep-sleep mode for battery remotes; keep scheduler for base/wifi nodes.
if str(getattr(settings, 'NODE_TYPE', 'base')).lower() == 'remote':
    try:
        from remote_node import run_remote_deep_sleep
        run_remote_deep_sleep()
    except Exception as e:
        _record_startup_exception('run_remote_deep_sleep', e)
        asyncio.run(main())
else:
    asyncio.run(main())

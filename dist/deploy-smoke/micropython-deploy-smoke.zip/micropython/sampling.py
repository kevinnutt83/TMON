# TMON Verion 2.00.1d - Sampling module for TMON MicroPython firmware...

import sdata
import settings
from utils import free_pins_i2c
import uasyncio as asyncio
from machine import I2C, Pin, SoftI2C
from utils import debug_print, log_error, log_exception, record_exception
from tmon import frostwatchCheck, heatwatchCheck, beginFrostOperations, beginHeatOperations, endFrostOperations, endHeatOperations
import machine


#Sampling Routine for sample all sensor types if they are enabled
async def sampleEnviroment():
    from utils import led_status_flash
    import sdata as _s
    _s.sampling_active = True
    try:
        led_status_flash('SAMPLE_TEMP')
        await sampleTemp()
        
        if getattr(settings, 'SAMPLE_SOIL', False):
            led_status_flash('SAMPLE_SOIL')
            await sampleSoil()
        
        led_status_flash('SAMPLE_BAR')
        await frost_and_heat_watch()
    finally:
        _s.sampling_active = False


async def sampleTemp():
    if not getattr(settings, 'SAMPLE_TEMP', True):
        return

    if not getattr(settings, 'ENABLE_sensorBME280', False):
        return

    # === INTERIOR DEVICE ENCLOSURE SENSOR ===
    if (getattr(settings, 'SAMPLE_DEVICE_TEMP', False) or
        getattr(settings, 'SAMPLE_DEVICE_BAR', False) or
        getattr(settings, 'SAMPLE_DEVICE_HUMID', False)) and settings.ENABLE_DEVICE_BME280:
        await free_pins_i2c()
        await sampleBME280Interior()
        await free_pins_i2c()

    # === EXTERIOR PROBE SENSOR ===
    if (getattr(settings, 'SAMPLE_PROBE_TEMP', False) or
        getattr(settings, 'SAMPLE_PROBE_BAR', False) or
        getattr(settings, 'SAMPLE_PROBE_HUMID', False)) and settings.ENABLE_PROBE_BME280:
        await free_pins_i2c()
        await sampleBME280Probe()
        await free_pins_i2c()


async def _read_bme280(i2c, target="probe"):
    sensor = None
    primary_addr = getattr(settings, 'i2cAddr_BME280', 0x76)
    fallback_addr = getattr(settings, 'i2cAddr_BME280_FALLBACK', 0x77)
    try:
        from BME280 import BME280

        # Scan bus and try primary then fallback address
        detected_addr = None
        try:
            devices = i2c.scan()
            if getattr(settings, 'DEBUG_BME280', False):
                await debug_print(f"BME280 {target} I2C scan: {[hex(d) for d in devices]}", "BME280")
            if primary_addr in devices:
                detected_addr = primary_addr
            elif fallback_addr in devices:
                detected_addr = fallback_addr
                await debug_print(f"BME280 {target}: using fallback address 0x{fallback_addr:02X}", "BME280")
            else:
                await debug_print(f"BME280 {target}: address not found on bus (scanned {[hex(d) for d in devices]})", "WARN")
                return None
        except Exception as scan_e:
            await debug_print(f"BME280 {target} I2C scan error: {scan_e}, trying primary", "WARN")
            detected_addr = primary_addr

        # Attempt init with retries
        last_err = None
        for attempt in range(3):
            try:
                sensor = BME280(i2c=i2c, address=detected_addr)
                sensor.get_calib_param()
                data = sensor.readData()

                temp_c = data[1]
                temp_f = (temp_c * 9/5) + 32
                humid = data[2]
                bar = data[0]

                if target == "probe":
                    if getattr(settings, 'SAMPLE_PROBE_TEMP', False):
                        sdata.cur_temp_c = temp_c
                        sdata.cur_temp_f = temp_f
                        await findLowestTemp(temp_f)
                        await findHighestTemp(temp_f)
                    if getattr(settings, 'SAMPLE_PROBE_BAR', False):
                        sdata.cur_bar_pres = bar
                        await findLowestBar(bar)
                        await findHighestBar(bar)
                    if getattr(settings, 'SAMPLE_PROBE_HUMID', False):
                        sdata.cur_humid = humid
                        await findLowestHumid(humid)
                        await findHighestHumid(humid)

                else:  # device
                    if getattr(settings, 'SAMPLE_DEVICE_TEMP', False):
                        sdata.cur_device_temp_c = temp_c
                        sdata.cur_device_temp_f = temp_f
                    if getattr(settings, 'SAMPLE_DEVICE_BAR', False):
                        sdata.cur_device_bar_pres = bar
                    if getattr(settings, 'SAMPLE_DEVICE_HUMID', False):
                        sdata.cur_device_humid = humid

                if getattr(settings, 'DEBUG_BME280', False) or getattr(settings, 'DEBUG_TEMP', False):
                    await debug_print(
                        f"BME280 {target}: p:{bar:7.2f} t:{temp_c:6.2f} h:{humid:6.2f}",
                        "TEMP"
                    )
                return data
            except Exception as e:
                last_err = e
                await debug_print(f"BME280 {target} attempt {attempt+1} error: {type(e).__name__}: {e}", "WARN")
                sensor = None
                await asyncio.sleep(0.5)

        # All retry attempts failed
        await log_error(f"BME280 {target} failed after 3 attempts: {last_err}", "BME280")
        await debug_print(f"BME280 {target} failed after retries - disabling sensor", "ERROR")

        if target == "device":
            settings.ENABLE_DEVICE_BME280 = False
            settings.SAMPLE_DEVICE_TEMP = False
            settings.SAMPLE_DEVICE_BAR = False
            settings.SAMPLE_DEVICE_HUMID = False
        else:
            settings.ENABLE_PROBE_BME280 = False
            settings.SAMPLE_PROBE_TEMP = False
            settings.SAMPLE_PROBE_BAR = False
            settings.SAMPLE_PROBE_HUMID = False
        return None

    except Exception as e:
        await log_error(f"BME280 {target} fatal error: {e}", "BME280")
        await debug_print(f"BME280 {target} fatal error - disabling sensor", "ERROR")

        if target == "device":
            settings.ENABLE_DEVICE_BME280 = False
            settings.SAMPLE_DEVICE_TEMP = False
            settings.SAMPLE_DEVICE_BAR = False
            settings.SAMPLE_DEVICE_HUMID = False
        else:
            settings.ENABLE_PROBE_BME280 = False
            settings.SAMPLE_PROBE_TEMP = False
            settings.SAMPLE_PROBE_BAR = False
            settings.SAMPLE_PROBE_HUMID = False
        return None
    finally:
        if sensor is not None:
            try:
                if hasattr(sensor, "i2c") and hasattr(sensor.i2c, "deinit"):
                    sensor.i2c.deinit()
            except Exception as e:
                record_exception('_read_bme280.deinit', e, status='WARN')
            sensor.i2c = None


async def sampleBME280Interior():
    from utils import led_status_flash
    led_status_flash('SAMPLE_DEVICE_TEMP')
    try:
        from oled import display_message
        await display_message("Sampling Interior Temp", 1)
    except Exception as e:
        await log_exception('sampleBME280Interior.display', e, status='WARN')

    i2c = I2C(0, scl=Pin(settings.DEVICE_TEMP_SCL_PIN),
              sda=Pin(settings.DEVICE_TEMP_SDA_PIN), freq=400000)
    await _read_bme280(i2c, target="device")


async def sampleBME280Probe():
    from utils import led_status_flash
    led_status_flash('SAMPLE_BME280')
    try:
        from oled import display_message
        await display_message("Sampling Exterior Probe", 1)
    except Exception as e:
        await log_exception('sampleBME280Probe.display', e, status='WARN')

    # Probe uses SoftI2C to avoid conflict with OLED on hardware I2C(1)
    i2c = SoftI2C(scl=Pin(settings.BME280_PROBE_SCL_PIN),
                  sda=Pin(settings.BME280_PROBE_SDA_PIN), freq=400000)
    await _read_bme280(i2c, target="probe")


async def sampleSoil():
    if not getattr(settings, 'SAMPLE_SOIL', False):
        return

    import sdata as _s
    from utils import led_status_flash
    _s.sampling_active = True

    try:
        try:
            from oled import display_message
            await display_message("Sampling Soil Probe", 1)
        except Exception as e:
            await log_exception('sampleSoil.display', e, status='WARN')

        result = await sample_soil_probe()

        if result and result.get("status") == "success":
            _s.cur_soil_moisture = result.get("moisture_percent", 0.0)
            _s.cur_soil_temp_c = result.get("temperature_c")
            _s.cur_soil_temp_f = result.get("temperature_f")

            if getattr(settings, 'DEBUG_SOIL_PROBE', False):
                await debug_print(
                    f"Soil Moisture: {_s.cur_soil_moisture:.1f}% | SoilTemp: {_s.cur_soil_temp_f:.1f}°F",
                    "SOIL"
                )
        else:
            await debug_print("Soil probe returned no valid data", "SOIL")

    except Exception as e:
        await log_exception("sampleSoil wrapper", e)
    finally:
        _s.sampling_active = False


async def findLowestTemp(compareTemp, source='local'):
    try:
        if compareTemp is None:
            return
        if sdata.lowest_temp_f == 0 or compareTemp < sdata.lowest_temp_f:
            sdata.lowest_temp_f = compareTemp
            await frostwatchCheck()
    except Exception as e:
        await log_exception('findLowestTemp', e, status='WARN')

async def findLowestBar(compareBar, source='local'):
    try:
        if compareBar is None:
            return
        if sdata.lowest_bar == 0 or compareBar < sdata.lowest_bar:
            sdata.lowest_bar = compareBar
    except Exception as e:
        await log_exception('findLowestBar', e, status='WARN')

async def findLowestHumid(compareHumid, source='local'):
    try:
        if compareHumid is None:
            return
        if sdata.lowest_humid == 0 or compareHumid < sdata.lowest_humid:
            sdata.lowest_humid = compareHumid
    except Exception as e:
        await log_exception('findLowestHumid', e, status='WARN')

async def findHighestTemp(compareTemp, source='local'):
    try:
        if compareTemp is None:
            return
        if compareTemp > sdata.highest_temp_f:
            sdata.highest_temp_f = compareTemp
            await heatwatchCheck()
    except Exception as e:
        await log_exception('findHighestTemp', e, status='WARN')

async def findHighestBar(compareBar, source='local'):
    try:
        if compareBar is None:
            return
        if compareBar > sdata.highest_bar:
            sdata.highest_bar = compareBar
    except Exception as e:
        await log_exception('findHighestBar', e, status='WARN')

async def findHighestHumid(compareHumid, source='local'):
    try:
        if compareHumid is None:
            return
        if compareHumid > sdata.highest_humid:
            sdata.highest_humid = compareHumid
    except Exception as e:
        await log_exception('findHighestHumid', e, status='WARN')

async def frost_and_heat_watch():
    try:
        if getattr(settings, 'ENABLE_FROSTWATCH', False):
            if sdata.cur_temp_f < getattr(settings, 'FROSTWATCH_ACTIVE_TEMP', 70):
                sdata.frostwatch_active = True
            else:
                sdata.frostwatch_active = False
            if sdata.cur_temp_f < getattr(settings, 'FROSTWATCH_ALERT_TEMP', 42):
                sdata.frost = True
            else:
                sdata.frost = False
            if not sdata.frost_act:
                if sdata.cur_temp_f < getattr(settings, 'FROSTWATCH_ACTION_TEMP', 38):
                    sdata.frost_act = True
                    await beginFrostOperations()
            else:
                if sdata.cur_temp_f > getattr(settings, 'FROSTWATCH_STANDDOWN_TEMP', 40):
                    sdata.frost_act = False
                    await endFrostOperations()
        if getattr(settings, 'ENABLE_HEATWATCH', False):
            if sdata.cur_temp_f > getattr(settings, 'HEATWATCH_ACTIVE_TEMP', 90):
                sdata.heatwatch_active = True
            else:
                sdata.heatwatch_active = False
            if sdata.cur_temp_f > getattr(settings, 'HEATWATCH_ALERT_TEMP', 100):
                sdata.heat = True
            else:
                sdata.heat = False
            if not sdata.heat_act:
                if sdata.cur_temp_f > getattr(settings, 'HEATWATCH_ACTION_TEMP', 110):
                    sdata.heat_act = True
                    await beginHeatOperations()
            else:
                if sdata.cur_temp_f < getattr(settings, 'HEATWATCH_STANDDOWN_TEMP', 105):
                    sdata.heat_act = False
                    await endHeatOperations()
    except Exception as e:
        from utils import log_exception
        await log_exception("sample frost/heat watch", e)
        

async def sample_soil_probe():
    if not getattr(settings, 'SAMPLE_SOIL', False):
        await debug_print("Soil sampling disabled (SAMPLE_SOIL=False)", "SOIL")
        return {"status": "disabled"}

    await debug_print("Starting soil probe sampling...", "SOIL")

    try:
        adc_moist = machine.ADC(settings.SOIL_PROBE_PIN)
        adc_moist.atten(machine.ADC.ATTN_11DB)          

        readings = []
        for _ in range(10):
            readings.append(adc_moist.read_u16())
            await asyncio.sleep_ms(10)                  

        raw_moisture = sum(readings) // len(readings)

        await debug_print(f"Raw moisture (u16 avg): {raw_moisture}", "SOIL")

        min_raw = getattr(settings, 'MIN_SOIL_MOISTURE', 45)
        max_raw = getattr(settings, 'MAX_SOIL_MOISTURE', 120)

        if raw_moisture >= 65500:
            await debug_print("Error: Sensor maxed out — check wiring/power", "SOIL")
            moisture_pct = 0.0
        elif max_raw > min_raw:
            moisture_pct = (max_raw - raw_moisture) * 100.0 / (max_raw - min_raw)
            moisture_pct = max(0.0, min(100.0, moisture_pct))
        else:
            moisture_pct = 50.0

        await debug_print(f"Soil Moisture: {moisture_pct:.1f}%", "SOIL")

        temperature_c = None
        temperature_f = None
        try:
            adc_temp = machine.ADC(9)                   
            adc_temp.atten(machine.ADC.ATTN_11DB)

            t_readings = [adc_temp.read_u16() for _ in range(8)]
            raw_temp = sum(t_readings) // len(t_readings)

            await debug_print(f"Raw temperature (u16 avg): {raw_temp}", "SOIL")

            temperature_c = (raw_temp / 65535.0) * 100.0 - 50.0
            temperature_c -= 16.666666666666668
            temperature_f = (temperature_c * 9 / 5) + 32

            await debug_print(f"Temperature: {temperature_c:.2f}°C ({temperature_f:.1f}°F)", "SOIL")
        except Exception as temp_e:
            from utils import log_exception
            await log_exception("soil probe temperature sensor", temp_e)

        return {
            "status": "success",
            "moisture_percent": round(moisture_pct, 1),
            "raw_moisture": raw_moisture,
            "temperature_c": round(temperature_c, 2) if temperature_c is not None else None,
            "temperature_f": round(temperature_f, 1) if temperature_f is not None else None,
            "raw_temperature": raw_temp if 'raw_temp' in locals() else None
        }

    except Exception as e:
        from utils import log_exception
        await log_exception("soil probe sampling", e)
        return {"status": "error", "message": str(e)}
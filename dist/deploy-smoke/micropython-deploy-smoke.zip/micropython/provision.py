# TMON Verion 2.00.1d - Minimal MicroPython provisioning client that uses the canonical micropython/settings.py values. This module defines a function to fetch provisioning settings from the TMON Admin hub using either GET or POST requests, with support for multiple endpoint paths and robust error handling. It also includes a function to apply the fetched settings, which can trigger firmware updates and persist important configuration values. The module is designed to be called during the device's first boot sequence to ensure it is properly registered and configured with the server before normal operation begins. GC management is included to maintain stability on resource-constrained hardware.

# Minimal MicroPython provisioning client that uses the canonical micropython/settings.py values.

import json
import os
try:
    import urequests as requests
except Exception:
    import requests  # fallback for host testing

# Import device settings robustly: prefer local settings module; fallback to micropython.settings
device_settings = None
try:
    import settings as local_settings  # when module is executed in its dir
    device_settings = local_settings
except Exception:
    try:
        from micropython import settings as local_settings  # package-style import
        device_settings = local_settings
    except Exception:
        device_settings = None

# Resolve configuration from settings or sensible defaults
DEFAULT_BASE = getattr(device_settings, 'TMON_ADMIN_API_URL', "https://tmonsystems.com") if device_settings else "https://tmonsystems.com"
API_PATHS = getattr(device_settings, 'PROVISION_PATHS', ['/wp-json/tmon/v1/device/provision', '/wp-json/tmon/v1/provision']) if device_settings else ['/wp-json/tmon/v1/device/provision', '/wp-json/tmon/v1/provision']
REQUEST_TIMEOUT = getattr(device_settings, 'HTTP_TIMEOUT_S', 20) if device_settings else 20
CHUNK_SIZE = getattr(device_settings, 'FIRMWARE_DOWNLOAD_CHUNK_SIZE', 1024) if device_settings else 1024

try:
    from utils import record_exception
except Exception:
    def record_exception(context, exc, status='ERROR'):
        try:
            print(f"[{status}] {context}: {exc}")
        except Exception:
            pass

def _attempt_endpoint(base_url, endpoint, params=None, json_body=None, timeout=REQUEST_TIMEOUT):
    url = base_url.rstrip("/") + endpoint
    try:
        if json_body is not None:
            resp = requests.post(url, json=json_body, timeout=timeout)
        else:
            if params:
                qs = "&".join("{}={}".format(k, v) for k, v in params.items())
                url = url + "?" + qs
            resp = requests.get(url, timeout=timeout)
        if not resp:
            return None, 'no_response'
        code = getattr(resp, 'status_code', None)
        if code not in (200, 201):
            return None, 'http_error_%s' % code
        try:
            return resp.json(), None
        except Exception as e:
            record_exception('provision._attempt_endpoint.resp_json', e, status='WARN')
            try:
                return json.loads(getattr(resp, 'text', '{}')), None
            except Exception as e:
                return None, str(e)
    except Exception as e:
        return None, str(e)
    finally:
        # NEW: GC after endpoint attempt
        try:
            import gc
            gc.collect()
        except Exception as e:
            record_exception('provision._attempt_endpoint.gc_collect', e, status='WARN')

def fetch_provisioning(unit_id=None, machine_id=None, base_url=None, force=False):
    """
    Fetch provisioning settings from Admin. Uses device settings if unit/machine not specified.
    Returns the settings dict or None.
    """
    base = base_url or DEFAULT_BASE

    # fallback to persisted values in settings if not passed
    if not unit_id and device_settings and getattr(device_settings, 'UNIT_ID', None):
        unit_id = getattr(device_settings, 'UNIT_ID', None)
    if not machine_id and device_settings and getattr(device_settings, 'MACHINE_ID', None):
        machine_id = getattr(device_settings, 'MACHINE_ID', None)

    if not (unit_id or machine_id):
        return None

    params = {}
    if unit_id:
        params['unit_id'] = unit_id
    if machine_id:
        params['machine_id'] = machine_id
    if force:
        params['force'] = '1'

    # Try GET on each path first, then fallback to POST
    for path in API_PATHS:
        body, err = _attempt_endpoint(base, path, params=params)
        if err is None and body and 'provisioned' in body:
            site_val = body.get('site_url') or body.get('wordpress_api_url') or ''
            if (body.get('provisioned') or body.get('staged_exists')) and site_val:
                return {
                    'wordpress_api_url': site_val,
                    'site_url': site_val,
                    'NODE_TYPE': body.get('role') or '',
                    'UNIT_Name': body.get('unit_name') or '',
                    'FIRMWARE': body.get('firmware') or '',
                    'FIRMWARE_URL': body.get('firmware_url') or '',
                    'plan': body.get('plan') or '',
                    'WIFI_DISABLE_AFTER_PROVISION': ((body.get('role') or '') == 'remote')
                }
            if not body.get('provisioned'):
                return None
            return body.get('settings') or {}
    json_body = params
    for path in API_PATHS:
        body, err = _attempt_endpoint(base, path, json_body=json_body)
        if err is None and body and 'provisioned' in body:
            site_val = body.get('site_url') or body.get('wordpress_api_url') or ''
            if (body.get('provisioned') or body.get('staged_exists')) and site_val:
                return {
                    'wordpress_api_url': site_val,
                    'site_url': site_val,
                    'NODE_TYPE': body.get('role') or '',
                    'UNIT_Name': body.get('unit_name') or '',
                    'FIRMWARE': body.get('firmware') or '',
                    'FIRMWARE_URL': body.get('firmware_url') or '',
                    'plan': body.get('plan') or '',
                    'WIFI_DISABLE_AFTER_PROVISION': ((body.get('role') or '') == 'remote')
                }
            if not body.get('provisioned'):
                return None
            return body.get('settings') or {}
    return None

# firmware_updater expected in micropython directory; fallback to no-op
try:
    from firmware_updater import download_and_apply_firmware
except Exception as e:
    record_exception('provision.import_firmware_updater', e, status='WARN')
    def download_and_apply_firmware(url, version_hint=None, chunk_size=CHUNK_SIZE):
        try:
            from utils import provisioning_log
            provisioning_log(f"No firmware_updater; skipping firmware: {url}")
        except Exception as pe:
            record_exception('provision.firmware_updater_missing', pe, status='WARN')
            print("No firmware_updater; skipping firmware:", url)
        return True

def apply_settings(settings_doc):
    """
    Apply settings returned by Admin:
    - NODE_TYPE, UNIT_Name
    - FIRMWARE_URL -> call firmware_updater to download to OTA_BACKUP_DIR
    - WIFI_DISABLE_AFTER_PROVISION: device-specific action
    """
    if not isinstance(settings_doc, dict):
        return False

    node_type = settings_doc.get('NODE_TYPE')
    if node_type:
        try:
            from utils import provisioning_log
            provisioning_log(f"Setting NODE_TYPE: {node_type}")
        except Exception as e:
            record_exception('provision.apply_settings.log_node_type', e, status='WARN')
            print("Setting NODE_TYPE:", node_type)

    unit_name = settings_doc.get('UNIT_Name')
    if unit_name:
        try:
            from utils import provisioning_log
            provisioning_log(f"Setting UNIT_Name: {unit_name}")
        except Exception as e:
            record_exception('provision.apply_settings.log_unit_name', e, status='WARN')
            print("Setting UNIT_Name:", unit_name)

    fw_url = settings_doc.get('FIRMWARE_URL') or settings_doc.get('firmware_url')
    fw_ver = settings_doc.get('FIRMWARE') or settings_doc.get('firmware')
    if fw_url:
        try:
            from utils import provisioning_log
            provisioning_log(f"Firmware requested: {fw_ver} {fw_url}")
        except Exception as e:
            record_exception('provision.apply_settings.log_firmware_request', e, status='WARN')
            print("Firmware requested:", fw_ver, fw_url)
        try:
            download_and_apply_firmware(fw_url, fw_ver, chunk_size=CHUNK_SIZE)
        except Exception as e:
            try:
                from utils import provisioning_log
                provisioning_log(f"Firmware download/apply failed: {e}")
            except Exception as pe:
                record_exception('provision.apply_settings.log_firmware_fail', pe, status='WARN')
                print("Firmware download/apply failed:", e)

    if settings_doc.get('WIFI_DISABLE_AFTER_PROVISION', False):
        try:
            from utils import provisioning_log
            provisioning_log("Configured to disable WiFi after provisioning (device-specific).")
        except Exception as e:
            record_exception('provision.apply_settings.log_wifi_disable', e, status='WARN')
            print("Configured to disable WiFi after provisioning (device-specific).")

    # NEW: fallback mapping from alternative keys
    if not node_type and settings_doc.get('role'):
        node_type = settings_doc.get('role')
        try:
            from utils import provisioning_log
            provisioning_log(f"Setting NODE_TYPE (role fallback): {node_type}")
        except Exception as e:
            record_exception('provision.apply_settings.log_role_fallback', e, status='WARN')
            print("Setting NODE_TYPE (role fallback):", node_type)
    if not unit_name and settings_doc.get('unit_name'):
        unit_name = settings_doc.get('unit_name')
        try:
            from utils import provisioning_log
            provisioning_log(f"Setting UNIT_Name (unit_name fallback): {unit_name}")
        except Exception as e:
            record_exception('provision.apply_settings.log_unit_name_fallback', e, status='WARN')
            print("Setting UNIT_Name (unit_name fallback):", unit_name)
    # Persist mapped fields to settings module
    try:
        import settings as _s
        # Persist UNIT_ID if present (best-effort)
        if settings_doc.get('unit_id'):
            try:
                from utils import persist_unit_id
                _s.UNIT_ID = str(settings_doc.get('unit_id'))
                persist_unit_id(_s.UNIT_ID)
            except Exception as e:
                record_exception('provision.apply_settings.persist_unit_id', e, status='WARN')
        if settings_doc.get('plan'): _s.PLAN = settings_doc.get('plan')
        if settings_doc.get('site_url') or settings_doc.get('wordpress_api_url'):
            _s.WORDPRESS_API_URL = settings_doc.get('site_url') or settings_doc.get('wordpress_api_url')
            try:
                path = getattr(_s, 'WORDPRESS_API_URL_FILE', _s.LOG_DIR + '/wordpress_api_url.txt')
                with open(path, 'w') as f:
                    f.write(_s.WORDPRESS_API_URL)
            except Exception as e:
                record_exception('provision.apply_settings.persist_wordpress_api_url', e, status='WARN')
        # Persist unit name via utils to maintain consistent behavior
        if unit_name:
            try:
                from utils import persist_unit_name
                persist_unit_name(unit_name)
                _s.UNIT_Name = unit_name
            except Exception as e:
                record_exception('provision.apply_settings.persist_unit_name', e, status='WARN')
        # If role -> persist node type and if remote, optionally disable WiFi
        if node_type:
            try:
                _s.NODE_TYPE = node_type
                from utils import persist_node_type
                persist_node_type(node_type)
                if str(node_type).lower() == 'remote' and settings_doc.get('WIFI_DISABLE_AFTER_PROVISION', False):
                    try:
                        _s.ENABLE_WIFI = False
                    except Exception as e:
                        record_exception('provision.apply_settings.disable_wifi_remote', e, status='WARN')
            except Exception as e:
                record_exception('provision.apply_settings.persist_node_type', e, status='WARN')
    except Exception as e:
        record_exception('provision.apply_settings.settings_persist', e)

    # NEW: GC after applying/persisting provisioning settings
    try:
        import gc
        gc.collect()
    except Exception as e:
        record_exception('provision.apply_settings.gc_collect', e, status='WARN')

    # Additional device-specific settings application here
    return True

# Exported helpers
__all__ = ['fetch_provisioning', 'apply_settings']

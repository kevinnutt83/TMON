# TMON Verion 2.00.1d - Centralized data store for TMON MicroPython firmware. ...

# Performance/health metrics for reporting
loop_runtime = 0
script_runtime = 0
sys_voltage = 0
free_mem = 0
cpu_temp = 0
error_count = 0
last_error = ''

# LoRa Information
lora_SigStr = 0
lora_snr = 0

# NEW: LoRa activity/connection flags used by OLED header refresh logic
LORA_CONNECTED = False
lora_last_rx_ts = 0
lora_last_tx_ts = 0
lora_last_init_ts = 0

# Engine controller metrics
engine1_speed_rpm = 0
engine2_speed_rpm = 0
engine1_batt_v = 0
engine2_batt_v = 0
engine_last_poll_ts = 0

# Exterior BME280 probe data. This sensor is mounted outside the enclosure.
cur_temp_c = 0
cur_temp_f = 0
cur_bar_pres = 0
cur_humid = 0
# NEW: indicate sampling in progress so OLED can render sampling-only content
sampling_active = False

# Device enclosure interior BME280 data.
cur_device_temp_c = 0.0
cur_device_temp_f = 0.0
cur_device_bar_pres = 0.0
cur_device_humid = 0.0

# Base Station Data Variables
lowest_temp_f = 0
highest_temp_f = 0
lowest_bar = 0
highest_bar = 0
lowest_humid = 0
highest_humid = 0

# Relay States
relay1_on = False
relay2_on = False
relay3_on = False
relay4_on = False
relay5_on = False
relay6_on = False
relay7_on = False
relay8_on = False

# Relay runtime counters (seconds)
relay1_runtime_s = 0
relay2_runtime_s = 0
relay3_runtime_s = 0
relay4_runtime_s = 0
relay5_runtime_s = 0
relay6_runtime_s = 0
relay7_runtime_s = 0
relay8_runtime_s = 0

# Frost and Heat Monitoring Data Variables
frostwatch_active = False
heatwatch_active = False
frost = False
heat = False
frost_act = False
heat_act = False

# WiFi/Network State
WIFI_CONNECTED = False
WAN_CONNECTED = False
wifi_rssi = 0

# Messages
last_message = ''

# GPS state (populated if settings.GPS_ENABLED)
gps_lat = None
gps_lng = None
gps_alt_m = None
gps_accuracy_m = None
gps_last_fix_ts = None

#Soil Probe Output Values
cur_soil_moisture = 0.0
cur_soil_temp_c = None
cur_soil_temp_f = None


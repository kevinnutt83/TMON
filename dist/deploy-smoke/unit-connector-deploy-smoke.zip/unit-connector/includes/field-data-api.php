<?php
// REST API for field data and data history log upload
// Permission: allow logged-in users locally, else require hub read auth (token/keys)
if (!function_exists('tmon_uc_read_permission')) {
function tmon_uc_read_permission($request) {
    if (is_user_logged_in()) return true;
    if (function_exists('tmon_uc_admin_read_auth')) return tmon_uc_admin_read_auth($request);
    return false;
}}

add_action('rest_api_init', function() {
    register_rest_route('tmon/v1', '/device/field-data', array(
        'methods' => 'POST',
        'callback' => 'tmon_uc_receive_field_data',
        'permission_callback' => '__return_true',
    ));
    register_rest_route('tmon/v1', '/device/data-history', array(
        'methods' => 'POST',
        'callback' => 'tmon_uc_receive_data_history',
        'permission_callback' => '__return_true',
    ));
    register_rest_route('tmon/v1', '/device/history', array(
        'methods' => 'GET',
        'callback' => 'tmon_uc_get_device_history',
        // Publicly readable so front-end shortcodes can fetch without special headers
        'permission_callback' => '__return_true',
        'args' => array(
            'unit_id' => array('required' => true),
            'hours' => array('required' => false),
        ),
    ));

    register_rest_route('tmon/v1', '/device/sdata', array(
        'methods' => 'GET',
        'callback' => 'tmon_uc_get_device_sdata',
        'permission_callback' => '__return_true',
        'args' => array(
            'unit_id' => array('required' => true),
        ),
    ));

    // Token-protected CSV export (normalized fields); optional unit_id/time-window filters and gzip
    register_rest_route('tmon/v1', '/admin/field-data.csv', [
        'methods' => 'GET',
        'callback' => 'tmon_uc_rest_export_field_data',
        'permission_callback' => 'tmon_uc_read_permission',
        'args' => [
            'unit_id' => ['required' => false],
            'since'   => ['required' => false],
            'until'   => ['required' => false],
            'hours'   => ['required' => false],
            'gzip'    => ['required' => false],
        ],
    ]);

    // Token-protected JSON listing of recent field data rows (for Admin hub UI aggregation)
    register_rest_route('tmon/v1', '/admin/field-data', [
        'methods' => 'GET',
        'callback' => 'tmon_uc_rest_list_field_data',
        'permission_callback' => 'tmon_uc_read_permission',
        'args' => [
            'unit_id' => ['required' => false],
            'hours'   => ['required' => false],
            'limit'   => ['required' => false],
        ],
    ]);
});

// Optional: verify HMAC signature on field-data payloads if a secret is configured
function tmon_uc_fd_hmac_secret() {
    $opt = get_option('tmon_uc_field_data_hmac_secret', '');
    if (!$opt && defined('TMON_FIELD_DATA_HMAC_SECRET')) {
        $opt = TMON_FIELD_DATA_HMAC_SECRET;
    }
    return (string)$opt;
}

function tmon_uc_fd_verify_sig($data) {
    $secret = tmon_uc_fd_hmac_secret();
    if (!$secret) return true; // not enforced if no secret configured
    $sig = isset($data['sig']) ? (string)$data['sig'] : '';
    $sig_v = isset($data['sig_v']) ? intval($data['sig_v']) : 0;
    if ($sig_v !== 1 || $sig === '') return false;
    // Canonical string: unit_id|firmware_version|node_type|count|first_ts|last_ts
    $get = function($arr, $key) { return isset($arr[$key]) ? (string)$arr[$key] : ''; };
    $core = [
        $get($data, 'unit_id'),
        $get($data, 'firmware_version'),
        $get($data, 'node_type'),
    ];
    $arr = [];
    if (isset($data['data']) && is_array($data['data'])) { $arr = $data['data']; }
    $count = count($arr);
    $first_ts = '';
    $last_ts = '';
    if ($count > 0) {
        $first = $arr[0];
        $last = $arr[$count-1];
        $first_ts = isset($first['timestamp']) ? (string)$first['timestamp'] : (isset($first['time']) ? (string)$first['time'] : '');
        $last_ts = isset($last['timestamp']) ? (string)$last['timestamp'] : (isset($last['time']) ? (string)$last['time'] : '');
    }
    $canon = implode('|', array_merge($core, [strval($count), $first_ts, $last_ts]));
    $digest = hash('sha256', $secret . $canon);
    // Accept truncated signatures (prefix match)
    $len = min(strlen($sig), strlen($digest));
    return hash_equals(substr($digest, 0, $len), substr($sig, 0, $len));
}

// Truthy helper reused for relay and feature detection
function tmon_uc_truthy($val) {
    return in_array($val, [true, 1, '1', 'true', 'yes', 'on'], true);
}


// Helper: convert stored MySQL DATETIME (assumed UTC) to a WP site-local Unix timestamp
if (! function_exists('tmon_uc_mysql_to_local_timestamp')) {
function tmon_uc_mysql_to_local_timestamp($mysql_dt) {
    if (!$mysql_dt) return 0;
    // Stored datetime is UTC/GMT; get_date_from_gmt converts it to site-local string
    $local = get_date_from_gmt($mysql_dt);
    $ts = strtotime($local);
    return $ts ? $ts : 0;
}}

function tmon_uc_rest_list_field_data($request) {
    global $wpdb;
    $unit_id = sanitize_text_field($request->get_param('unit_id') ?? '');
    $hours = intval($request->get_param('hours') ?? 24);
    if ($hours <= 0) $hours = 24;
    $limit = intval($request->get_param('limit') ?? 200);
    $limit = max(1, min(2000, $limit));

    // Use WP site-local time for "since" then convert to GMT for SQL comparison
    $since_ts = (int) ( current_time('timestamp') - ($hours * 3600) );
    $since_local = date_i18n('Y-m-d H:i:s', $since_ts);
    $since = get_gmt_from_date($since_local);

    $table = $wpdb->prefix.'tmon_field_data';
    $where = ['created_at >= %s'];
    $args = [$since];
    if ($unit_id) { $where[] = 'unit_id = %s'; $args[] = $unit_id; }
    $sql = "SELECT unit_id, data, created_at FROM $table WHERE ".implode(' AND ', $where)." ORDER BY created_at DESC LIMIT $limit";
    $rows = $wpdb->get_results($wpdb->prepare($sql, ...$args), ARRAY_A);
    $out = [];
    foreach ($rows as $r) {
        $payload = json_decode($r['data'], true);
        if (!is_array($payload)) $payload = [];
        $payload['unit_id'] = $r['unit_id'];
        // Provide a site-local ISO8601 string in addition to raw DB value using WP timezone helpers
        $payload['ts_iso'] = date_i18n(DATE_ISO8601, tmon_uc_mysql_to_local_timestamp($r['created_at']));
        $out[] = $payload;
    }
    return rest_ensure_response(['status'=>'ok','rows'=>$out]);
}

function tmon_uc_rest_export_field_data($request) {
    global $wpdb;
    $unit_id = sanitize_text_field($request->get_param('unit_id') ?? '');
    $since_param = $request->get_param('since');
    $until_param = $request->get_param('until');
    $hours_param = $request->get_param('hours');
    $gzip_param  = $request->get_param('gzip');

    // Determine time window. created_at is stored with current_time('mysql') (site local time).
    $now_ts = function_exists('current_time') ? current_time('timestamp') : time();
    $since_ts = null;
    $until_ts = null;
    if (!empty($since_param)) {
        $t = strtotime($since_param);
        if ($t !== false) { $since_ts = $t; }
    }
    if (!empty($hours_param) && !$since_ts) {
        $h = intval($hours_param);
        if ($h > 0) { $since_ts = $now_ts - ($h * 3600); }
    }
    if (!empty($until_param)) {
        $t = strtotime($until_param);
        if ($t !== false) { $until_ts = $t; }
    }
    if (!$until_ts) { $until_ts = $now_ts; }
    $since = $since_ts ? get_gmt_from_date(date_i18n('Y-m-d H:i:s', $since_ts)) : null;
    $until = $until_ts ? get_gmt_from_date(date_i18n('Y-m-d H:i:s', $until_ts)) : null;

    // Parse gzip flag
    $gzip = false;
    if ($gzip_param !== null) {
        $val = strtolower((string)$gzip_param);
        $gzip = in_array($val, ['1','true','yes','on'], true);
    }

    // Build CSV in memory
    $fh = fopen('php://temp', 'r+');
    // Header row consistent with admin export
    fputcsv($fh, ['created_at','unit_id','origin','timestamp','name','machine_id','temp_f','temp_c','humidity','pressure','voltage_v','wifi_rssi','lora_rssi','free_mem','gps_lat','gps_lng','gps_alt_m','gps_accuracy_m','gps_last_fix_ts']);
    $query = "SELECT unit_id, data, created_at FROM {$wpdb->prefix}tmon_field_data";
    $qargs = [];
    $where = [];
    if ($unit_id) { $where[] = "unit_id=%s"; $qargs[] = $unit_id; }
    if ($since)  { $where[] = "created_at >= %s"; $qargs[] = $since; }
    if ($until)  { $where[] = "created_at <= %s"; $qargs[] = $until; }
    if ($where) { $query .= ' WHERE ' . implode(' AND ', $where); }
    $query .= " ORDER BY created_at ASC";
    $rows = $qargs ? $wpdb->get_results($wpdb->prepare($query, ...$qargs), ARRAY_A) : $wpdb->get_results($query, ARRAY_A);
    foreach ($rows as $r) {
        $d = json_decode($r['data'], true);
        if (!is_array($d)) continue;
        $origin = 'unknown';
        if (!empty($d['machine_id'])) {
            $origin = 'remote';
        } elseif (!empty($d['NODE_TYPE'])) {
            $origin = strtolower($d['NODE_TYPE']) === 'remote' ? 'remote' : 'base';
        } else {
            // Heuristic: if keys look like compact remote telemetry (t_f, hum, bar, v, fm), assume remote
            $remote_keys = 0;
            foreach (['t_f','t_c','hum','bar','v','fm'] as $k) { if (isset($d[$k])) $remote_keys++; }
            $origin = ($remote_keys >= 3) ? 'remote' : 'base';
        }
        $flat = [
            tmon_uc_format_mysql_datetime($r['created_at']),
            $r['unit_id'],
            $origin,
            $d['timestamp'] ?? ($d['time'] ?? ''),
            $d['name'] ?? '',
            $d['machine_id'] ?? '',
            isset($d['t_f']) ? $d['t_f'] : ($d['cur_temp_f'] ?? ''),
            isset($d['t_c']) ? $d['t_c'] : ($d['cur_temp_c'] ?? ''),
            isset($d['hum']) ? $d['hum'] : ($d['cur_humid'] ?? ''),
            isset($d['bar']) ? $d['bar'] : ($d['cur_bar_pres'] ?? ''),
            isset($d['v']) ? $d['v'] : ($d['sys_voltage'] ?? ''),
            $d['wifi_rssi'] ?? '',
            $d['lora_SigStr'] ?? '',
            isset($d['fm']) ? $d['fm'] : ($d['free_mem'] ?? ''),
            $d['gps_lat'] ?? ($d['GPS_LAT'] ?? ''),
            $d['gps_lng'] ?? ($d['GPS_LNG'] ?? ''),
            $d['gps_alt_m'] ?? ($d['GPS_ALT_M'] ?? ''),
            $d['gps_accuracy_m'] ?? ($d['GPS_ACCURACY_M'] ?? ''),
            $d['gps_last_fix_ts'] ?? ($d['GPS_LAST_FIX_TS'] ?? ''),
        ];
        fputcsv($fh, $flat);
    }
    rewind($fh);
    $csv = stream_get_contents($fh);
    fclose($fh);
    // Filename composition
    $filename = 'tmon_field_data' . ($unit_id ? ('_'.$unit_id) : '');
    if ($since_ts || $until_ts) {
        // Use WP site-local formatting for filenames
        $fn_since = $since_ts ? date_i18n('Ymd_His', $since_ts) : 'start';
        $fn_until = $until_ts ? date_i18n('Ymd_His', $until_ts) : 'now';
        $filename .= "_{$fn_since}-{$fn_until}";
    }
    $is_gz = $gzip && function_exists('gzencode');
    $body = $is_gz ? gzencode($csv, 6) : $csv;
    $filename .= $is_gz ? '.csv.gz' : '.csv';
    $resp = new WP_REST_Response($body, 200);
    $resp->header('Content-Type', $is_gz ? 'application/gzip' : 'text/csv; charset=utf-8');
    if ($is_gz) { $resp->header('Content-Encoding', 'gzip'); $resp->header('Vary', 'Accept-Encoding'); }
    $resp->header('X-Content-Type-Options', 'nosniff');
    $resp->header('Content-Disposition', 'attachment; filename="'.$filename.'"');
    return $resp;
}

function tmon_uc_receive_field_data($request) {
    global $wpdb;
    $data = $request->get_json_params();
    if (!is_array($data) || empty($data)) {
        return new WP_REST_Response(['status'=>'error','message'=>'Invalid JSON payload'], 400);
    }
    // Enforce HMAC when configured
    $hsec = tmon_uc_fd_hmac_secret();
    if ($hsec && !tmon_uc_fd_verify_sig($data)) {
        return new WP_REST_Response(['status'=>'error','message'=>'HMAC verification failed'], 401);
    }
    $log_dir = WP_CONTENT_DIR . '/tmon-field-logs';
    if (!file_exists($log_dir)) {
        mkdir($log_dir, 0777, true);
    }
    $unit_id = isset($data['unit_id']) ? sanitize_text_field($data['unit_id']) : '';
    $machine_id = isset($data['machine_id']) ? sanitize_text_field($data['machine_id']) : '';
    $log_file = $log_dir . "/field_data_{$unit_id}.log";
    // Save inbound JSON envelope (raw for troubleshooting)
    file_put_contents($log_file, wp_json_encode($data) . "\n", FILE_APPEND);

    // Helper: flatten a record to a CSV-ready array with consistent keys
    $flatten = function($rec) {
        if (!is_array($rec)) return [];
        $out = [];
        $out['timestamp'] = $rec['timestamp'] ?? ($rec['time'] ?? current_time('mysql'));
        $out['unit_id']   = $rec['unit_id'] ?? '';
        $out['machine_id']= $rec['machine_id'] ?? '';
        $out['name']      = $rec['name'] ?? '';
        // Common sensor aliases
        $out['temp_f']    = isset($rec['t_f']) ? $rec['t_f'] : ($rec['cur_temp_f'] ?? null);
        $out['temp_c']    = isset($rec['t_c']) ? $rec['t_c'] : ($rec['cur_temp_c'] ?? null);
        $out['humidity']  = isset($rec['hum']) ? $rec['hum'] : ($rec['cur_humid'] ?? null);
        $out['pressure']  = isset($rec['bar']) ? $rec['bar'] : ($rec['cur_bar_pres'] ?? null);
        $out['voltage_v'] = isset($rec['v']) ? $rec['v'] : ($rec['sys_voltage'] ?? null);
        $out['wifi_rssi'] = $rec['wifi_rssi'] ?? null;
        $out['lora_rssi'] = $rec['lora_SigStr'] ?? null;
        $out['free_mem']  = isset($rec['fm']) ? $rec['fm'] : ($rec['free_mem'] ?? null);
        // Device interior sensor fields
        $out['device_temp_f']   = $rec['dt_f'] ?? ($rec['cur_device_temp_f'] ?? null);
        $out['device_temp_c']   = $rec['dt_c'] ?? ($rec['cur_device_temp_c'] ?? null);
        $out['device_humid']    = $rec['dh'] ?? ($rec['cur_device_humid'] ?? null);
        $out['device_bar_pres'] = $rec['db'] ?? ($rec['cur_device_bar_pres'] ?? null);
        // Soil sensor fields
        $out['soil_moisture']   = $rec['sm'] ?? ($rec['cur_soil_moisture'] ?? null);
        $out['soil_temp_c']     = $rec['st_c'] ?? ($rec['cur_soil_temp_c'] ?? null);
        $out['soil_temp_f']     = $rec['st_f'] ?? ($rec['cur_soil_temp_f'] ?? null);
        // System / diagnostics
        $out['cpu_temp']        = $rec['cpu'] ?? ($rec['cpu_temp'] ?? null);
        $out['node_type']       = $rec['NODE_TYPE'] ?? ($rec['node_type'] ?? null);
        $out['error_count']     = $rec['ec'] ?? ($rec['error_count'] ?? null);
        $out['script_runtime']  = $rec['sr'] ?? ($rec['script_runtime'] ?? null);
        $out['loop_runtime']    = $rec['lr'] ?? ($rec['loop_runtime'] ?? null);
        $out['lora_snr']        = $rec['lora_snr'] ?? null;
        $out['wifi_connected']  = $rec['WIFI_CONNECTED'] ?? null;
        $out['wan_connected']   = $rec['WAN_CONNECTED'] ?? null;
        $out['lora_connected']  = $rec['LORA_CONNECTED'] ?? null;
        $out['lowest_temp_f']   = $rec['lowest_temp_f'] ?? null;
        $out['highest_temp_f']  = $rec['highest_temp_f'] ?? null;
        $out['lowest_bar']      = $rec['lowest_bar'] ?? null;
        $out['highest_bar']     = $rec['highest_bar'] ?? null;
        $out['lowest_humid']    = $rec['lowest_humid'] ?? null;
        $out['highest_humid']   = $rec['highest_humid'] ?? null;
        $out['last_message']    = $rec['last_message'] ?? null;
        // Engine fields
        $out['engine1_speed_rpm'] = $rec['e1r'] ?? ($rec['engine1_speed_rpm'] ?? null);
        $out['engine1_batt_v']    = $rec['e1v'] ?? ($rec['engine1_batt_v'] ?? null);
        $out['engine2_speed_rpm'] = $rec['e2r'] ?? ($rec['engine2_speed_rpm'] ?? null);
        $out['engine2_batt_v']    = $rec['e2v'] ?? ($rec['engine2_batt_v'] ?? null);
        // GPS fields if present
        $out['gps_lat']   = $rec['gps_lat'] ?? ($rec['GPS_LAT'] ?? null);
        $out['gps_lng']   = $rec['gps_lng'] ?? ($rec['GPS_LNG'] ?? null);
        $out['gps_alt_m'] = $rec['gps_alt_m'] ?? ($rec['GPS_ALT_M'] ?? null);
        $out['gps_accuracy_m'] = $rec['gps_accuracy_m'] ?? ($rec['GPS_ACCURACY_M'] ?? null);
        $out['gps_last_fix_ts'] = $rec['gps_last_fix_ts'] ?? ($rec['GPS_LAST_FIX_TS'] ?? null);
        return $out;
    };

    // Helper: write CSV with header if new/empty
    $write_csv = function($csv_file, $row_assoc) {
        if (!$row_assoc) return;
        $is_new = !file_exists($csv_file) || filesize($csv_file) === 0;
        $fh = fopen($csv_file, 'a');
        if ($fh) {
            if ($is_new) {
                fputcsv($fh, array_keys($row_assoc));
            }
            // Sanitize values, cast scalars
            $vals = [];
            foreach ($row_assoc as $v) {
                if (is_array($v) || is_object($v)) {
                    $vals[] = wp_json_encode($v);
                } else {
                    $vals[] = is_scalar($v) ? $v : strval($v);
                }
            }
            fputcsv($fh, $vals);
            fclose($fh);
        }
    };

    // Helper: forward unauthorized device to central admin for provisioning
    $forward_unknown = function($rec_unit, $rec_machine, $payload) {
    $hub = defined('TMON_ADMIN_HUB_URL') ? TMON_ADMIN_HUB_URL : get_option('tmon_uc_hub_url', 'https://tmonsystems.com');
    if (!$hub) { $hub = 'https://tmonsystems.com'; }
        if (!$hub) return; // no hub configured
        $endpoint = rtrim($hub, '/') . '/wp-json/tmon-admin/v1/ingest-unknown';
        $body = [
            'unit_id' => $rec_unit,
            'machine_id' => $rec_machine,
            'site_url' => home_url(),
        ];
        // Best-effort HTTP POST
        wp_remote_post($endpoint, [
            'timeout' => 5,
            'headers' => [ 'Content-Type' => 'application/json' ],
            'body' => wp_json_encode($body),
        ]);
    };

    // Normalize records: support either a single reading or a batch under data
    $records = [];
    if (isset($data['data']) && is_array($data['data'])) {
        $records = $data['data'];
    } else {
        $records = [$data];
    }

    // If machine_id is provided but unit_id is empty or placeholder, try to map
    if ($machine_id && (!$unit_id || $unit_id === '800000' || $unit_id === '999999')) {
        $mapped = $wpdb->get_var($wpdb->prepare("SELECT unit_id FROM {$wpdb->prefix}tmon_devices WHERE machine_id=%s", $machine_id));
        if ($mapped) {
            $unit_id = $mapped;
        }
    }

    $received = 0;
    $envelope_defaults = [
        'unit_id' => $unit_id,
        'machine_id' => $machine_id,
        'firmware_version' => $data['firmware_version'] ?? null,
        'NODE_TYPE' => $data['NODE_TYPE'] ?? ($data['node_type'] ?? null),
    ];

    foreach ($records as $rec) {
        if (!is_array($rec)) continue;
        $rec = array_merge(array_filter($envelope_defaults, static function($value) {
            return $value !== null && $value !== '';
        }), $rec);
        // REMOTE_NODE_INFO may be on the record (from base) or top-level
        $remote_map = [];
        if (isset($rec['REMOTE_NODE_INFO']) && is_array($rec['REMOTE_NODE_INFO'])) {
            $remote_map = $rec['REMOTE_NODE_INFO'];
        } elseif (isset($data['REMOTE_NODE_INFO']) && is_array($data['REMOTE_NODE_INFO'])) {
            $remote_map = $data['REMOTE_NODE_INFO'];
        }

        // First, persist the primary record (base or direct remote),
        // then persist each embedded remote record if provided.
        $targets = [];
        // Always include the primary record so base station data is stored
        $targets[] = $rec;
        if (!empty($remote_map)) {
            // For each remote embedded record, prepare a per-remote target
            foreach ($remote_map as $rid => $rdata) {
                if (!is_array($rdata)) continue;
                $rdata['unit_id'] = isset($rdata['unit_id']) ? $rdata['unit_id'] : $rid;
                $targets[] = $rdata;
            }
        }

        foreach ($targets as $t) {
            $rec_unit = isset($t['unit_id']) ? sanitize_text_field($t['unit_id']) : $unit_id;
            $rec_machine = isset($t['machine_id']) ? sanitize_text_field($t['machine_id']) : $machine_id;

            // Resolve unit_id from existing mapping via machine_id when missing
            if (!$rec_unit && $rec_machine) {
                $row = $wpdb->get_row($wpdb->prepare("SELECT unit_id FROM {$wpdb->prefix}tmon_devices WHERE machine_id=%s", $rec_machine), ARRAY_A);
                if ($row && !empty($row['unit_id'])) {
                    $rec_unit = $row['unit_id'];
                }
            }

            // If still no unit_id, do not mint a synthetic one; forward for provisioning and skip local insert
            if (!$rec_unit) {
                $forward_unknown($rec_unit, $rec_machine, $t);
                continue;
            }

            // Persist machine_id to unit mapping if both present
            if ($rec_unit && $rec_machine) {
                $row = $wpdb->get_row($wpdb->prepare("SELECT unit_id, machine_id FROM {$wpdb->prefix}tmon_devices WHERE unit_id=%s OR machine_id=%s", $rec_unit, $rec_machine), ARRAY_A);
                if ($row) {
                    // Update existing row to ensure mapping is set
                    $wpdb->update($wpdb->prefix.'tmon_devices', ['machine_id'=>$rec_machine, 'last_seen'=>current_time('mysql', true)], ['unit_id'=>$row['unit_id']]);
                    $rec_unit = $row['unit_id'];
                } else {
                    // Create new mapping row minimally (only when unit_id provided)
                    $wpdb->insert($wpdb->prefix.'tmon_devices', [
                        'unit_id' => $rec_unit,
                        'machine_id' => $rec_machine,
                        'unit_name' => $rec_unit,
                        'last_seen' => current_time('mysql', true),
                        'suspended' => 0,
                    ]);
                }
            }

            // Per-record authorization via tmon-admin
            $authorized = apply_filters('tmon_admin_authorize_device', true, $rec_unit, $rec_machine);
            if (!$authorized) {
                // forward for provisioning and skip local store
                $forward_unknown($rec_unit, $rec_machine, $t);
                continue;
            }
            $rec_json = wp_json_encode($t);
            // Persist raw field data row
            $wpdb->insert(
                $wpdb->prefix . 'tmon_field_data',
                [
                    'unit_id' => $rec_unit,
                    'data' => $rec_json,
                    'created_at' => current_time('mysql', true)
                ]
            );
            // Append normalized CSV row per received record (per unit)
            $csv_file_unit = $log_dir . "/field_data_{$rec_unit}.csv";
            $write_csv($csv_file_unit, $flatten($t));
            // Ensure device exists; update last_seen and unit_name if provided
            $exists = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}tmon_devices WHERE unit_id=%s", $rec_unit));
            $incoming_name = isset($t['name']) ? sanitize_text_field($t['name']) : '';
            if (!$exists) {
                $wpdb->insert($wpdb->prefix.'tmon_devices', [
                    'unit_id' => $rec_unit,
                    'unit_name' => $incoming_name ?: $rec_unit,
                    'last_seen' => current_time('mysql', true),
                    'suspended' => 0,
                ]);
            } else {
                $update = ['last_seen' => current_time('mysql', true)];
                if ($incoming_name) { $update['unit_name'] = $incoming_name; }
                $wpdb->update($wpdb->prefix.'tmon_devices', $update, ['unit_id' => $rec_unit]);
            }

            // Mirror into UC devices table so Provisioned Devices lists reporters
            if (function_exists('uc_devices_upsert_row')) {
                uc_devices_upsert_row([
                    'unit_id' => $rec_unit,
                    'machine_id' => $rec_machine,
                    'unit_name' => $incoming_name ?: $rec_unit,
                    'role' => $t['role'] ?? '',
                    'assigned' => 1,
                ]);
            } else {
                // Fallback minimal insert
                $uc_table = $wpdb->prefix . 'tmon_uc_devices';
                if (function_exists('uc_devices_ensure_table')) { uc_devices_ensure_table(); }
                $wpdb->query($wpdb->prepare(
                    "INSERT INTO {$uc_table} (unit_id, machine_id, unit_name, role, assigned, updated_at)
                     VALUES (%s,%s,%s,%s,1,NOW())
                     ON DUPLICATE KEY UPDATE machine_id=VALUES(machine_id), unit_name=VALUES(unit_name), role=VALUES(role), assigned=1, updated_at=NOW()",
                    $rec_unit, $rec_machine, $incoming_name ?: $rec_unit, isset($t['role']) ? sanitize_text_field($t['role']) : ''
                ));
            }
            // Update status JSON with latest GPS if present
            $gps_lat = $t['gps_lat'] ?? ($t['GPS_LAT'] ?? null);
            $gps_lng = $t['gps_lng'] ?? ($t['GPS_LNG'] ?? null);
            if ($gps_lat !== null && $gps_lng !== null) {
                $row = $wpdb->get_row($wpdb->prepare("SELECT status FROM {$wpdb->prefix}tmon_devices WHERE unit_id=%s", $rec_unit));
                $status = $row && $row->status ? json_decode($row->status, true) : [];
                if (!is_array($status)) $status = [];
                $status['gps_lat'] = floatval($gps_lat);
                $status['gps_lng'] = floatval($gps_lng);
                if (isset($t['gps_alt_m']) || isset($t['GPS_ALT_M'])) $status['gps_alt_m'] = floatval($t['gps_alt_m'] ?? $t['GPS_ALT_M']);
                if (isset($t['gps_accuracy_m']) || isset($t['GPS_ACCURACY_M'])) $status['gps_accuracy_m'] = floatval($t['gps_accuracy_m'] ?? $t['GPS_ACCURACY_M']);
                if (isset($t['gps_last_fix_ts']) || isset($t['GPS_LAST_FIX_TS'])) $status['gps_last_fix_ts'] = $t['gps_last_fix_ts'] ?? $t['GPS_LAST_FIX_TS'];
                $wpdb->update($wpdb->prefix.'tmon_devices', ['status' => wp_json_encode($status)], ['unit_id' => $rec_unit]);
            }
            // Forward to tmon-admin for centralized admin processing
            do_action('tmon_admin_receive_field_data', $rec_unit, $t);
            $received++;
        }
    }

    // Include resolved unit_id/machine_id for device to persist mapping
    return rest_ensure_response(['status' => 'ok', 'received' => $received > 0, 'count' => $received, 'unit_id' => $unit_id ?: ($data['unit_id'] ?? ''), 'machine_id' => $machine_id]);
}

function tmon_uc_receive_data_history($request) {
    $unit_id = $request->get_param('unit_id');
    $file = $request->get_file_params()['file'] ?? null;
    $log_dir = WP_CONTENT_DIR . '/tmon-field-logs';
    if (!file_exists($log_dir)) {
        mkdir($log_dir, 0777, true);
    }
    if ($file && $unit_id) {
        $dest = $log_dir . "/data_history_{$unit_id}_" . time() . ".log";
        move_uploaded_file($file['tmp_name'], $dest);
        // Flag for hub sync/backfill
        set_transient('tmon_uc_devices_dirty', 1, 15 * MINUTE_IN_SECONDS);
        return rest_ensure_response(['status' => 'ok', 'received' => true]);
    }
    return rest_ensure_response(['status' => 'error', 'received' => false]);
}

function tmon_uc_get_device_history($request) {
    global $wpdb;
    $unit_id = sanitize_text_field($request->get_param('unit_id'));
    $hours = intval($request->get_param('hours')) ?: 24;
    // Use WP site-local time to compute the 'since' cutoff then convert to GMT for SQL comparison.
    $since_ts = (int) ( current_time('timestamp') - ($hours * 3600) );
    $since_local = date_i18n('Y-m-d H:i:s', $since_ts);
    $since = get_gmt_from_date($since_local);
    $enabled_relays = [];
    // Seed enabled relays from stored settings if present
    $device_row = $wpdb->get_row($wpdb->prepare("SELECT settings FROM {$wpdb->prefix}tmon_devices WHERE unit_id=%s", $unit_id), ARRAY_A);
    if ($device_row && !empty($device_row['settings'])) {
        $settings = json_decode($device_row['settings'], true);
        if (is_array($settings)) {
            for ($i = 1; $i <= 8; $i++) {
                $k = 'ENABLE_RELAY' . $i;
                if (array_key_exists($k, $settings) && tmon_uc_truthy($settings[$k])) {
                    $enabled_relays[] = $i;
                }
            }
        }
    }
    $rows = $wpdb->get_results($wpdb->prepare("SELECT data, created_at FROM {$wpdb->prefix}tmon_field_data WHERE unit_id=%s AND created_at >= %s ORDER BY created_at ASC", $unit_id, $since), ARRAY_A);
    $points = [];
    foreach ($rows as $r) {
        $d = json_decode($r['data'], true);
        if (!is_array($d)) continue;
        $relay_states = [];
        for ($i = 1; $i <= 8; $i++) {
            $enable_key = 'ENABLE_RELAY' . $i;
            $state_key = 'relay' . $i . '_on';
            if (array_key_exists($enable_key, $d) && tmon_uc_truthy($d[$enable_key]) && !in_array($i, $enabled_relays, true)) {
                $enabled_relays[] = $i;
            }
            if (array_key_exists($state_key, $d)) {
                if (!in_array($i, $enabled_relays, true)) {
                    $enabled_relays[] = $i;
                }
                $relay_states[$state_key] = tmon_uc_truthy($d[$state_key]) ? 1 : 0;
            }
        }
        $points[] = [
            // expose ISO timestamps in site-local time for charting/labels
            't' => date_i18n(DATE_ISO8601, tmon_uc_mysql_to_local_timestamp($r['created_at'])),
            'temp_f' => $d['t_f'] ?? ($d['cur_temp_f'] ?? null),
            'humid' => $d['hum'] ?? ($d['cur_humid'] ?? null),
            'bar' => $d['bar'] ?? ($d['cur_bar_pres'] ?? null),
            'volt' => $d['v'] ?? ($d['sys_voltage'] ?? null),
            'device_temp_f' => $d['dt_f'] ?? ($d['cur_device_temp_f'] ?? null),
            'device_humid' => $d['dh'] ?? ($d['cur_device_humid'] ?? null),
            'device_bar' => $d['db'] ?? ($d['cur_device_bar_pres'] ?? null),
            'soil_moisture' => $d['sm'] ?? ($d['cur_soil_moisture'] ?? null),
            'soil_temp_f' => $d['st_f'] ?? ($d['cur_soil_temp_f'] ?? null),
            'cpu_temp' => $d['cpu'] ?? ($d['cpu_temp'] ?? null),
            'lora_snr' => $d['lora_snr'] ?? null,
            'wifi_connected' => $d['WIFI_CONNECTED'] ?? null,
            'wan_connected' => $d['WAN_CONNECTED'] ?? null,
            'lora_connected' => $d['LORA_CONNECTED'] ?? null,
            'lowest_temp_f' => $d['lowest_temp_f'] ?? null,
            'highest_temp_f' => $d['highest_temp_f'] ?? null,
            'lowest_bar' => $d['lowest_bar'] ?? null,
            'highest_bar' => $d['highest_bar'] ?? null,
            'lowest_humid' => $d['lowest_humid'] ?? null,
            'highest_humid' => $d['highest_humid'] ?? null,
            'engine1_rpm' => $d['e1r'] ?? ($d['engine1_speed_rpm'] ?? null),
            'engine1_batt' => $d['e1v'] ?? ($d['engine1_batt_v'] ?? null),
            'engine2_rpm' => $d['e2r'] ?? ($d['engine2_speed_rpm'] ?? null),
            'engine2_batt' => $d['e2v'] ?? ($d['engine2_batt_v'] ?? null),
            'relay' => $relay_states,
        ];
    }
    sort($enabled_relays);
    $enabled_relays = array_values(array_unique($enabled_relays));
    return rest_ensure_response(['status' => 'ok', 'unit_id' => $unit_id, 'hours' => $hours, 'enabled_relays' => $enabled_relays, 'points' => $points]);
}

function tmon_uc_get_device_sdata($request) {
    global $wpdb;
    $unit_id = sanitize_text_field($request->get_param('unit_id'));
    if (!$unit_id) return rest_ensure_response(['status' => 'error', 'message' => 'unit_id required']);
    $row = $wpdb->get_row($wpdb->prepare("SELECT data, created_at FROM {$wpdb->prefix}tmon_field_data WHERE unit_id=%s ORDER BY created_at DESC LIMIT 1", $unit_id), ARRAY_A);
    if (!$row) return rest_ensure_response(['status' => 'ok', 'unit_id' => $unit_id, 'data' => [], 'created_at' => null]);
    $data = json_decode($row['data'], true);
    if (!is_array($data)) $data = [];
    $friendly = [
        // Prefer device-provided timestamp when available; otherwise show site-local formatted DB created_at
        'Timestamp' => isset($data['timestamp']) ? $data['timestamp'] : tmon_uc_format_mysql_datetime($row['created_at']),
        'Machine ID' => $data['machine_id'] ?? null,
        'Node Type' => $data['NODE_TYPE'] ?? ($data['node_type'] ?? null),
        // Probe sensors
        'Probe Temp (F)' => $data['t_f'] ?? ($data['cur_temp_f'] ?? null),
        'Probe Temp (C)' => $data['t_c'] ?? ($data['cur_temp_c'] ?? null),
        'Probe Humidity (%)' => $data['hum'] ?? ($data['cur_humid'] ?? null),
        'Probe Pressure (hPa)' => $data['bar'] ?? ($data['cur_bar_pres'] ?? null),
        // Device interior sensors
        'Device Temp (F)' => $data['dt_f'] ?? ($data['cur_device_temp_f'] ?? null),
        'Device Temp (C)' => $data['dt_c'] ?? ($data['cur_device_temp_c'] ?? null),
        'Device Humidity (%)' => $data['dh'] ?? ($data['cur_device_humid'] ?? null),
        'Device Pressure (hPa)' => $data['db'] ?? ($data['cur_device_bar_pres'] ?? null),
        // Soil sensors
        'Soil Moisture' => $data['sm'] ?? ($data['cur_soil_moisture'] ?? null),
        'Soil Temp (C)' => $data['st_c'] ?? ($data['cur_soil_temp_c'] ?? null),
        'Soil Temp (F)' => $data['st_f'] ?? ($data['cur_soil_temp_f'] ?? null),
        // System
        'Voltage (V)' => $data['v'] ?? ($data['sys_voltage'] ?? null),
        'CPU Temp' => $data['cpu'] ?? ($data['cpu_temp'] ?? null),
        'WiFi RSSI' => $data['wifi_rssi'] ?? null,
        'LoRa Signal' => $data['lora_SigStr'] ?? null,
        'LoRa SNR' => $data['lora_snr'] ?? null,
        'WiFi Connected' => $data['WIFI_CONNECTED'] ?? null,
        'WAN Connected' => $data['WAN_CONNECTED'] ?? null,
        'LoRa Connected' => $data['LORA_CONNECTED'] ?? null,
        'Free Mem (bytes)' => $data['fm'] ?? ($data['free_mem'] ?? null),
        'Firmware' => $data['firmware_version'] ?? null,
        'Lowest Probe Temp (F)' => $data['lowest_temp_f'] ?? null,
        'Highest Probe Temp (F)' => $data['highest_temp_f'] ?? null,
        'Lowest Pressure (hPa)' => $data['lowest_bar'] ?? null,
        'Highest Pressure (hPa)' => $data['highest_bar'] ?? null,
        'Lowest Humidity (%)' => $data['lowest_humid'] ?? null,
        'Highest Humidity (%)' => $data['highest_humid'] ?? null,
        // Engine
        'Engine 1 RPM' => $data['e1r'] ?? ($data['engine1_speed_rpm'] ?? null),
        'Engine 1 Battery (V)' => $data['e1v'] ?? ($data['engine1_batt_v'] ?? null),
        'Engine 2 RPM' => $data['e2r'] ?? ($data['engine2_speed_rpm'] ?? null),
        'Engine 2 Battery (V)' => $data['e2v'] ?? ($data['engine2_batt_v'] ?? null),
        // Runtime
        'Script Runtime (s)' => $data['sr'] ?? ($data['script_runtime'] ?? null),
        'Loop Runtime (s)' => $data['lr'] ?? ($data['loop_runtime'] ?? null),
        'Error Count' => $data['ec'] ?? ($data['error_count'] ?? null),
        'Last Error' => $data['last_error'] ?? null,
        'Last Message' => $data['last_message'] ?? null,
        'Frostwatch Active' => $data['frostwatch_active'] ?? null,
        'Heatwatch Active' => $data['heatwatch_active'] ?? null,
        'Frost Alert' => $data['frost'] ?? null,
        'Heat Alert' => $data['heat'] ?? null,
        'Device Name' => $data['name'] ?? '',
    ];
    return rest_ensure_response([
        'status' => 'ok',
        'unit_id' => $unit_id,
        'created_at' => $row['created_at'],
        'data' => $data,
        'friendly' => $friendly,
    ]);
}
